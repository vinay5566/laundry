import { Hero } from "@/components/Hero";
import { Services } from "@/components/Services";
import { ServiceCategories } from "@/components/ServiceCategories";
import { HowItWorks } from "@/components/HowItWorks";
import { WhyChooseUs } from "@/components/WhyChooseUs";
import { Testimonials } from "@/components/Testimonials";
import { Contact } from "@/components/Contact";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { OrderingFeatures } from "@/components/OrderingFeatures";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const Index = () => {
  const blogPosts = [
    {
      title: "How to Care for Delicate Fabrics",
      excerpt: "Learn the best practices for maintaining your delicate garments...",
      date: "March 15, 2024",
      imageUrl: "https://images.unsplash.com/photo-1489274495757-95c7c837b101",
    },
    {
      title: "The Benefits of Professional Dry Cleaning",
      excerpt: "Discover why professional dry cleaning is essential for your wardrobe...",
      date: "March 10, 2024",
      imageUrl: "https://images.unsplash.com/photo-1545173168-9f1947eebb7f",
    },
    {
      title: "Eco-Friendly Laundry Tips",
      excerpt: "Simple ways to make your laundry routine more environmentally friendly...",
      date: "March 5, 2024",
      imageUrl: "https://images.unsplash.com/photo-1517677208171-0bc6725a3e60",
    },
  ];

  const faqs = [
    {
      question: "How long does dry cleaning take?",
      answer: "Our standard dry cleaning service takes 2-3 business days. We also offer express service with same-day or next-day delivery for an additional fee.",
    },
    {
      question: "Do you offer pickup and delivery?",
      answer: "Yes, we offer free pickup and delivery services within our service area. You can schedule a pickup through our website or by calling us.",
    },
    {
      question: "What payment methods do you accept?",
      answer: "We accept all major credit cards, debit cards, and digital payments through our secure payment system.",
    },
  ];

  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-20">
        <Hero />
        <Services />
        <ServiceCategories />
        <OrderingFeatures />
        <HowItWorks />
        <WhyChooseUs />
        <Testimonials />

        {/* Blog Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Latest from Our Blog</h2>
              <p className="text-gray-600">Stay informed with our latest articles about garment care and laundry tips.</p>
            </div>
            <div className="grid md:grid-cols-3 gap-8 mb-8">
              {blogPosts.map((post, index) => (
                <div 
                  key={index} 
                  className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow duration-300"
                >
                  <img
                    src={post.imageUrl}
                    alt={post.title}
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-6">
                    <p className="text-sm text-gray-500 mb-2">{post.date}</p>
                    <h3 className="text-xl font-semibold mb-2">{post.title}</h3>
                    <p className="text-gray-600 mb-4">{post.excerpt}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="text-center">
              <Link to="/blog">
                <Button variant="outline" className="group">
                  Read More Articles
                  <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
              <p className="text-gray-600">Find quick answers to common questions about our services.</p>
            </div>
            <div className="max-w-3xl mx-auto">
              <Accordion type="single" collapsible className="w-full">
                {faqs.map((faq, index) => (
                  <AccordionItem key={index} value={`item-${index}`}>
                    <AccordionTrigger className="text-left">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent>
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
            <div className="text-center mt-8">
              <Link to="/faq">
                <Button variant="outline" className="group">
                  View All FAQs
                  <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
            </div>
          </div>
        </section>

        <Contact />
      </main>
      <Footer />
    </div>
  );
};

export default Index;