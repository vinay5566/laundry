import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const Pricing = () => {
  const mensWear = [
    { item: "Shirt/Tshirt", regPrice: "120/120", offerPrice: "96/96" },
    { item: "Trouser/Jeans", regPrice: "130/130", offerPrice: "104/104" },
    { item: "Coat", regPrice: "315", offerPrice: "252" },
    { item: "Suit 2 Pcs", regPrice: "445", offerPrice: "356" },
    { item: "Suit 3 Pcs", regPrice: "500", offerPrice: "400" },
    { item: "Jacket", regPrice: "315+", offerPrice: "252+" },
  ];

  const womensWear = [
    { item: "Kurta", regPrice: "110+", offerPrice: "88+" },
    { item: "Salwar", regPrice: "110+", offerPrice: "88+" },
    { item: "Saree", regPrice: "170+", offerPrice: "136+" },
    { item: "Dress", regPrice: "315+", offerPrice: "252+" },
    { item: "Lehenga", regPrice: "425+", offerPrice: "340+" },
    { item: "Shawl", regPrice: "140+", offerPrice: "112+" },
  ];

  const householdItems = [
    { item: "Single Blanket", regPrice: "375", offerPrice: "300" },
    { item: "Double Blanket", regPrice: "465", offerPrice: "372" },
    { item: "Single Bedsheet", regPrice: "105", offerPrice: "84" },
    { item: "Double Bedsheet", regPrice: "160", offerPrice: "128" },
    { item: "Single Quilt", regPrice: "465", offerPrice: "372" },
    { item: "Double Quilt", regPrice: "585", offerPrice: "468" },
    { item: "Carpet", regPrice: "35/Sq Ft", offerPrice: "28/Sq Ft" },
    { item: "Curtain", regPrice: "160+/Panel", offerPrice: "128+/Panel" },
  ];

  const shoes = [
    { item: "Sports", regPrice: "370", offerPrice: "296" },
    { item: "Canvas", regPrice: "370", offerPrice: "296" },
    { item: "Leather", regPrice: "480", offerPrice: "384" },
    { item: "Suede Leather", regPrice: "530", offerPrice: "424" },
    { item: "Boots", regPrice: "690+", offerPrice: "552+" },
  ];

  const laundryPrices = [
    { item: "Wash & Steam Iron", regPrice: "115/Kg", offerPrice: "90/Kg" },
    { item: "Wash & Fold", regPrice: "75/Kg", offerPrice: "75/Kg" },
    { item: "Premium Laundry", regPrice: "175/Kg", offerPrice: "175/Kg" },
    { item: "Woolen Laundry", regPrice: "175/Kg", offerPrice: "175/Kg" },
  ];

  const steamIronPrices = [
    { item: "Shirt/Tshirt", regPrice: "33/33", offerPrice: "26/26" },
    { item: "Trouser/Jeans", regPrice: "36/36", offerPrice: "29/29" },
    { item: "Coat", regPrice: "90", offerPrice: "72" },
    { item: "Suit 2 Pcs", regPrice: "105", offerPrice: "84" },
    { item: "Suit 3 Pcs", regPrice: "120", offerPrice: "96" },
    { item: "Jacket", regPrice: "90+", offerPrice: "72+" },
  ];

  const PriceTable = ({ title, data }: { title: string; data: Array<{ item: string; regPrice: string; offerPrice: string }> }) => (
    <section className="mb-8">
      <h2 className="text-2xl font-semibold mb-4">{title}</h2>
      <div className="rounded-lg border shadow-sm">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[40%]">Item</TableHead>
              <TableHead className="w-[30%]">Regular Price (₹)</TableHead>
              <TableHead className="w-[30%]">Offer Price (₹)</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.map((item, index) => (
              <TableRow key={index}>
                <TableCell className="font-medium">{item.item}</TableCell>
                <TableCell>{item.regPrice}</TableCell>
                <TableCell>{item.offerPrice}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </section>
  );

  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-20 pb-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-4 bg-clip-text text-transparent bg-brand-gradient">
              Our Pricing
            </h1>
            <p className="text-lg text-gray-600">
              Explore our competitive pricing for all services
            </p>
          </div>

          <div className="space-y-12">
            <PriceTable title="Men's Wear" data={mensWear} />
            <PriceTable title="Women's Wear" data={womensWear} />
            <PriceTable title="Household Items" data={householdItems} />
            <PriceTable title="Shoes" data={shoes} />
            <PriceTable title="Laundry Prices" data={laundryPrices} />
            <PriceTable title="Steam Iron Prices" data={steamIronPrices} />
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Pricing;