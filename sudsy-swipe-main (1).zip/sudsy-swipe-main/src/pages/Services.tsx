import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Shirt, WashingMachine, Clock, Sparkles, Home, PartyPopper } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const Services = () => {
  const services = [
    {
      title: "Wash & Fold",
      icon: WashingMachine,
      description: "Professional wash and fold service for your everyday laundry needs.",
      features: [
        "Thorough washing process",
        "Expert folding techniques",
        "24-hour turnaround",
        "Eco-friendly detergents"
      ]
    },
    {
      title: "Wash & Steam Iron",
      icon: Sparkles,
      description: "Get your clothes perfectly pressed with our wash and steam iron service.",
      features: [
        "Professional steam pressing",
        "Wrinkle-free finish",
        "Gentle care for fabrics",
        "Quality inspection"
      ]
    },
    {
      title: "Premium Laundry",
      icon: Clock,
      description: "Premium care for your high-end garments with special attention to detail.",
      features: [
        "Premium detergents",
        "Hand-wash options",
        "Fabric-specific care",
        "Extra attention to details"
      ]
    },
    {
      title: "Clothing Dry Cleaning",
      icon: Shirt,
      description: "Expert dry cleaning for all types of clothing items.",
      features: [
        "Stain removal",
        "Delicate fabric care",
        "Professional pressing",
        "Quality assurance"
      ]
    },
    {
      title: "Household Dry Cleaning",
      icon: Home,
      description: "Specialized cleaning for your household items.",
      features: [
        "Curtains & drapes",
        "Bedding & linens",
        "Upholstery cleaning",
        "Carpet cleaning"
      ]
    },
    {
      title: "Bridal & Party Wear Care",
      icon: PartyPopper,
      description: "Special care for your precious bridal and party wear garments.",
      features: [
        "Wedding dress care",
        "Designer wear cleaning",
        "Embellishment protection",
        "Premium packaging"
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="pt-20">
        <div className="container mx-auto px-4 py-8 md:py-16">
          <h1 className="text-3xl md:text-4xl font-bold text-center mb-3 md:mb-4">Our Services</h1>
          <p className="text-base md:text-lg text-gray-600 text-center mb-8 md:mb-12 max-w-2xl mx-auto">
            Professional laundry and dry cleaning services tailored to your needs
          </p>

          <div className="max-w-4xl mx-auto">
            <Accordion type="single" collapsible className="space-y-3 md:space-y-4">
              {services.map((service, index) => (
                <AccordionItem key={index} value={`item-${index}`} className="bg-white rounded-lg border">
                  <AccordionTrigger className="px-4 md:px-6 py-3 md:py-4 hover:no-underline">
                    <div className="flex items-center gap-3 md:gap-4">
                      <div className="w-10 h-10 md:w-12 md:h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <service.icon className="w-5 h-5 md:w-6 md:h-6 text-primary" />
                      </div>
                      <div className="text-left">
                        <h3 className="text-lg md:text-xl font-semibold">{service.title}</h3>
                        <p className="text-xs md:text-sm text-gray-600">{service.description}</p>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-4 md:px-6 pb-4">
                    <ul className="space-y-2 mt-2">
                      {service.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-center gap-2">
                          <div className="w-1.5 h-1.5 bg-primary rounded-full" />
                          <span className="text-sm md:text-base">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <Button className="mt-4 w-full sm:w-auto">Book Now</Button>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Services;