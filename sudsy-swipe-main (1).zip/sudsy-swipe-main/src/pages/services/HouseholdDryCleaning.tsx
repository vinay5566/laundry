import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Home } from "lucide-react";
import { Button } from "@/components/ui/button";

const HouseholdDryCleaning = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="pt-20">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <Home className="w-6 h-6 text-primary" />
              </div>
              <h1 className="text-4xl font-bold">Household Dry Cleaning</h1>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm p-8 mb-8">
              <p className="text-lg text-gray-600 mb-6">
                Expert dry cleaning service for all your household items and furnishings.
              </p>
              
              <h2 className="text-2xl font-semibold mb-4">Service Features</h2>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-primary rounded-full" />
                  <span>Curtains & drapes</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-primary rounded-full" />
                  <span>Bedding & linens</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-primary rounded-full" />
                  <span>Upholstery cleaning</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-primary rounded-full" />
                  <span>Carpet cleaning</span>
                </li>
              </ul>
              
              <Button size="lg" className="w-full md:w-auto">
                Schedule Pickup
              </Button>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default HouseholdDryCleaning;