import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { WashingMachine, Check, Award, Users, Leaf } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { useToast } from "@/components/ui/use-toast";

interface ServiceRequestForm {
  name: string;
  email: string;
  phone: string;
  pickupDate: string;
  pickupAddress: string;
  specialInstructions: string;
}

const WashAndFold = () => {
  const { toast } = useToast();
  const { register, handleSubmit, reset, formState: { errors } } = useForm<ServiceRequestForm>();

  const onSubmit = (data: ServiceRequestForm) => {
    console.log('Form submitted:', data);
    toast({
      title: "Request Submitted",
      description: "We'll contact you shortly to confirm your pickup.",
    });
    reset();
  };

  const certifications = [
    {
      icon: Award,
      title: "Hohenstein Certified Machinery",
      description: "To avoid color fading and shrinkage"
    },
    {
      icon: Award,
      title: "Woolmark Certified Machinery",
      description: "For handling delicate and woolen garments"
    },
    {
      icon: Users,
      title: "Professional & Experienced Team",
      description: "A team with expert knowledge in fabric care and processing"
    },
    {
      icon: Leaf,
      title: "German Eco Friendly Cleaning Solutions",
      description: "To prevent color loss and shrinkage: tough on stains, gentle on fabrics"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="pt-20">
        <div className="container mx-auto px-4 py-8 md:py-16">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center gap-3 md:gap-4 mb-6">
              <div className="w-10 h-10 md:w-12 md:h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <WashingMachine className="w-5 h-5 md:w-6 md:h-6 text-primary" />
              </div>
              <h1 className="text-2xl md:text-4xl font-bold">Wash & Fold Service</h1>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm p-4 md:p-8 mb-8">
              <p className="text-base md:text-lg text-gray-600 mb-6">
                Professional wash and fold service for your everyday laundry needs.
              </p>
              
              <h2 className="text-xl md:text-2xl font-semibold mb-4">Service Features</h2>
              <ul className="space-y-3 mb-6 md:mb-8">
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-primary rounded-full" />
                  <span className="text-sm md:text-base">Thorough washing process</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-primary rounded-full" />
                  <span className="text-sm md:text-base">Expert folding techniques</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-primary rounded-full" />
                  <span className="text-sm md:text-base">24-hour turnaround</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-primary rounded-full" />
                  <span className="text-sm md:text-base">Eco-friendly detergents</span>
                </li>
              </ul>

              {/* Certifications Section */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                {certifications.map((cert, index) => (
                  <div key={index} className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
                    <cert.icon className="w-6 h-6 text-primary mt-1" />
                    <div>
                      <h3 className="font-semibold text-gray-900">{cert.title}</h3>
                      <p className="text-sm text-gray-600">{cert.description}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="border-t pt-8 mt-8">
                <h2 className="text-xl md:text-2xl font-semibold mb-6">Schedule a Pickup</h2>
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label htmlFor="name" className="text-sm font-medium">Name</label>
                      <Input
                        id="name"
                        {...register("name", { required: "Name is required" })}
                        placeholder="Your name"
                      />
                      {errors.name && (
                        <p className="text-sm text-red-500">{errors.name.message}</p>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <label htmlFor="email" className="text-sm font-medium">Email</label>
                      <Input
                        id="email"
                        type="email"
                        {...register("email", { 
                          required: "Email is required",
                          pattern: {
                            value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                            message: "Invalid email address"
                          }
                        })}
                        placeholder="Your email"
                      />
                      {errors.email && (
                        <p className="text-sm text-red-500">{errors.email.message}</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="phone" className="text-sm font-medium">Phone</label>
                      <Input
                        id="phone"
                        {...register("phone", { required: "Phone number is required" })}
                        placeholder="Your phone number"
                      />
                      {errors.phone && (
                        <p className="text-sm text-red-500">{errors.phone.message}</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="pickupDate" className="text-sm font-medium">Pickup Date</label>
                      <Input
                        id="pickupDate"
                        type="date"
                        {...register("pickupDate", { required: "Pickup date is required" })}
                      />
                      {errors.pickupDate && (
                        <p className="text-sm text-red-500">{errors.pickupDate.message}</p>
                      )}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="pickupAddress" className="text-sm font-medium">Pickup Address</label>
                    <Input
                      id="pickupAddress"
                      {...register("pickupAddress", { required: "Pickup address is required" })}
                      placeholder="Your pickup address"
                    />
                    {errors.pickupAddress && (
                      <p className="text-sm text-red-500">{errors.pickupAddress.message}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="specialInstructions" className="text-sm font-medium">Special Instructions</label>
                    <Textarea
                      id="specialInstructions"
                      {...register("specialInstructions")}
                      placeholder="Any special instructions for pickup or cleaning"
                      className="min-h-[100px]"
                    />
                  </div>

                  <Button type="submit" size="lg" className="w-full md:w-auto">
                    Schedule Pickup
                  </Button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default WashAndFold;