import React from 'react';
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { HeroSection } from "@/components/franchise/HeroSection";
import { BenefitsSection } from "@/components/franchise/BenefitsSection";
import { InvestmentSection } from "@/components/franchise/InvestmentSection";
import { ApplicationForm } from "@/components/franchise/ApplicationForm";

const Franchise = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow pt-20">
        <HeroSection />
        <BenefitsSection />
        <InvestmentSection />
        <ApplicationForm />
      </main>
      <Footer />
    </div>
  );
};

export default Franchise;