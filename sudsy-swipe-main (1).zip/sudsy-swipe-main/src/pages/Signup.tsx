import { SignupForm } from "@/components/auth/SignupForm";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

const Signup = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow flex items-center justify-center py-12 px-4">
        <SignupForm />
      </main>
      <Footer />
    </div>
  );
};

export default Signup;